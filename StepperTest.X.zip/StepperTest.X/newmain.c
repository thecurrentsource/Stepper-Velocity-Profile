/*
 * File:   newmain.c
 * Author: derek
 *
 * Created on March 22, 2016, 12:09 PM
 */

#define _XTAL_FREQ 8000000           // crystal freq defined as 8 Mhz

// CONFIG1
#pragma config FOSC = INTOSCIO  // Oscillator Selection bits (INTRC oscillator; port I/O function on both RA6/OSC2/CLKO pin and RA7/OSC1/CLKI pin)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = ON       // RA5/MCLR/VPP Pin Function Select bit (RA5/MCLR/VPP pin function is MCLR)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = ON         // Low-Voltage Programming Enable bit (RB3/PGM pin has PGM function, Low-Voltage Programming enabled)
#pragma config CPD = OFF        // Data EE Memory Code Protection bit (Code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off)
#pragma config CCPMX = RB0      // CCP1 Pin Selection bit (CCP1 function on RB0)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

// CONFIG2
#pragma config FCMEN = ON       // Fail-Safe Clock Monitor Enable bit (Fail-Safe Clock Monitor enabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal External Switchover mode disabled)

#include <xc.h>


// switch input defines
#define ACCUMULATOR_MAX 1000

// motor & timer defines
#define MOT_STPS_REV    200                 // steps per revolution of motor
#define LIN_DISTANCE    3                   // distance needed to travel with linear actuator
#define LIN_PITCH       0.2                 // travel per revolution of linear actuator (inches)
#define MOT_UNKNOWN     0                   // motor in unknown velocity state
#define MOT_ACCEL       1                   // motor in acceleration state
#define MOT_MAXV        2                   // motor in max velocity state
#define MOT_DECEL       3                   // motor in deceleration state
#define MOT_TOTALSTP    (LIN_DISTANCE / LIN_PITCH) * MOT_STPS_REV   // total steps to achieve distance
#define MOT_STPACLDCL   (MOT_TOTALSTP / 10)                         // portion of above which is acl or dcl ramp
#define MOT_TOT_MIN_ACLDCL  (MOT_TOTALSTP - MOT_STPACLDCL)          // total acl dcl ramp (or plateau)
#define TIMER1_MAXV     0xfe                // maximum velocity value for timer1
#define TIMER1_INC      0x01                // increment step size during acl or dcl
#define TIMER1H_INIT    0x0a                // initial value of timer1 high register
#define TIMER1L_INIT    0xff                // initial value of timer1 low register (don't care)

#define RUNMODE_TRAP    0x01                // run trapezoidal profile
#define RUNMODE_RECT    0x02                // run rectangular profile

// global variables
int debounce_accumulator = ACCUMULATOR_MAX; // part of switch debounce
int runmode = RUNMODE_RECT;                 // default to running in rectangular mode
volatile int current_steps = 0;             // current step tracker
volatile int motor_state = MOT_ACCEL;       // are we in acl, maxv, or dcl
volatile int switch_state = 0x0f;
volatile int direction = 0;                 // what direction motor is turning

void main(void) {
    
    // initialize variables
    current_steps = 0;
    direction = 0;
    
    OSCCON = 0b01111000;        // 8 MHz internal osc
    
    // disable analog
    ANSEL = 0x00;
    ADCON0bits.ADON = 0;
      
    // setup port direction
    TRISA = 0x00;               // PORTA all output
    TRISB = 0x0f;               // PORTB input for switches
    PORTA = 0x00;               // Clear PORTA

    PIR1 = 0;                   // Clear interrupts
    PIE1 = 0;                   // Clear interrupt enable
    
    // Timer1 Registers: 
    // Prescaler=1:1; TMR1 Preset=53560; Freq=668.00267Hz; Period=1,497,000 ns
    T1CONbits.T1CKPS1 = 0;      // bits 5-4  Prescaler Rate Select bits
    T1CONbits.T1CKPS0 = 0;
    T1CONbits.T1OSCEN = 1;      // bit 3 Timer1 Oscillator Enable Control: bit 1=on
    T1CONbits.TMR1CS  = 0;      // bit 1 Timer1 Clock Source Select bit: 0=Internal clock (FOSC/4) / 1 = External clock from pin T1CKI (on the rising edge)
    T1CONbits.TMR1ON  = 1;      // bit 0 enables timer
    T1CONbits.T1INSYNC  = 1;    // do not sync with external clock
    TMR1H = TIMER1H_INIT;       // preset for timer1 MSB register (22uS isr)
    TMR1L = TIMER1L_INIT;       // preset for timer1 LSB register (22uS isr))
    PIR1bits.TMR1IF = 0;
    PIE1bits.TMR1IE = 1;        // Enable timer1 interrupt
    INTCONbits.PEIE = 1;
    INTCONbits.GIE = 1;         // Enable global interrupts
    
    
    while(1)
    {
        if (PORTBbits.RB0 == 0)
            runmode = RUNMODE_RECT;
        else if (PORTBbits.RB1 == 0)
            runmode = RUNMODE_TRAP;
    }
    return;
}


void interrupt isr (void){
    static char temp = 0;
    static char temp2 = TIMER1_INC;
    char rect1 = 0;
    char rect2 = 0;
    
    if(PIR1bits.TMR1IF)
    {
        // first order of business...
        // increment step count
        current_steps++;
        
        T1CONbits.TMR1ON  = 0;
        
        // set max velocity if rect mode
        if (runmode == RUNMODE_RECT)
        {
            rect1 = 0;       //force
            rect1 = TMR1L;
            rect2 = TIMER1_MAXV;
            TMR1H |= rect2;
            TMR1L = temp;
        }
        else
        {
            // setup motor state based on steps
            if (current_steps <= MOT_STPACLDCL)
                motor_state = MOT_ACCEL;   
            else if (current_steps > MOT_STPACLDCL)
                if(current_steps <= MOT_TOT_MIN_ACLDCL)
                    motor_state = MOT_MAXV;
            else if (current_steps > MOT_TOT_MIN_ACLDCL)
                motor_state = MOT_DECEL;

            // we are accelerating
            if (motor_state == MOT_ACCEL)
            {
                temp2 += TIMER1_INC;
                if (temp2 > TIMER1_MAXV)
                    temp2 = TIMER1_MAXV;
                temp = 0;
                temp += TMR1L;      // force a read of TIMER1 count register
                TMR1H |= temp2;     // Set TIMER1
                TMR1L = temp;       // force TIMER1 to latch all 16 bits of count value
            }
            else if(motor_state == MOT_DECEL )
            {
                temp2 -= TIMER1_INC;
                if (temp2 < TIMER1H_INIT)
                    temp2 = TIMER1H_INIT;

                temp = 0;
                temp += TMR1L;      // force a read of TIMER1 count register
                TMR1H |= temp2;     // Set TIMER1
                TMR1L = temp;       // force TIMER1 to latch all 16 bits of count value
            }
            else if(motor_state == MOT_MAXV )
            {
                // DO NOTHING (unless you have a good idea)
            }
        }
        
        // send out a pulse
        PORTAbits.RA1 = 1;  
        __delay_us(1000);
        PORTAbits.RA1 = 0;
        
        // check direction
        if (current_steps >= MOT_TOTALSTP)
        {
            current_steps = 0;
            // toggle direction bit
            if (direction == 0)
            {
                PORTAbits.RA0 = 1;
                direction = 1;
            }
            else if (direction == 1)
            {
                PORTAbits.RA0 = 0;
                direction = 0;
            }
        }
        
        T1CONbits.TMR1ON  = 1;
        PIR1bits.TMR1IF = 0; 
    }
}